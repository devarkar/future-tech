<?php

  $servername="localhost";
  $username="root";
  $pass="";
  $db="ft_db";

  try
  {
    $conn=new PDO("mysql:host=$servername;dbname=$db", $username,$pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "DB connect sucessfully!";

    if(isset($_POST["btn_product"]))
    {
      $p_name=$_POST["p_name"];
      $p_price=$_POST["p_price"];
      $p_description=$_POST["p_description"];
      $img=$_FILES["img"];
      $p_type=$_POST["p_type"];

      echo $p_name."<br/>";
      echo $p_price."<br/>";
      echo $p_description."<br/>";
      echo $p_type."<br/>";

      $sql="INSERT INTO tbl_product(`pname`,`price`,`description`,`ptid`) VALUES ('$p_name','$p_price','$p_description','$p_type')";
      $conn->exec($sql);
      echo "New Record insert is sucess!";




    }
  }
  catch(PDOException $e)
  {
    echo "Connection failed: ".$e->getMessage();
  }

$conn=null;

?>
