<!DOCTYPE html>
<html>
  <head>
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  </head>

  <body>

    <div class="container">

      <h1 class="flow-text" align="center">Future Tech Product Entry Console</h1>
      <hr/>

      <div class="row">
        <div class="col s12">
          <ul class="tabs">
            <li class="tab col s3"><a href="#test1">Product Data Entry</a></li>
            <li class="tab col s3"><a class="active" href="#test2">Product Type Entry</a></li>
            <li class="tab col s3"><a href="#test3">Test 3</a></li>
            <li class="tab col s3"><a href="#test4">Test 4</a></li>
          </ul>
        </div>
        <div id="test1" class="col s12">

          <!-- Product Data Form -->
          <div class="row">
            <center>
             <form class="col s12" action="product_insert.php" method="POST" enctype="multipart/form-data">

               <div class="row">
                  <div class="input-field col s6 offset-s3">
                    <input type="text" id="p-name" class="validate" name="p_name">
                    <label for="p-name">Product Name</label>
                  </div>
               </div>

               <div class="row">
                  <div class="input-field col s6 offset-s3">
                    <input type="text" id="p-price" class="validate" name="p_price">
                    <label for="p-price">Product Price</label>
                  </div>
               </div>


               <div class="row">
                 <div class="input-field col s6 offset-s3">

                   <textarea class="materialize-textarea" name="p_description"></textarea>
                   <label for="p-description">Product Description</label>
                 </div>
               </div>

               <div class="row">
                  <div class="input-field col s6 offset-s3">

               <div class="file-field input-field">
                 <input class="file-path validate" type="text"/>
                 <div class="btn">
                   <span>Image</span>
                   <input type="file" name="img" />
                 </div>
               </div>

               </div>
            </div>

               <div class="row">
                  <div class="input-field col s6 offset-s3">

                    <select class="browser-default" name="p_type">
                      <option value="" disabled selected>Product Type</option>

                      <?php

                      $servername="localhost";
                      $username="root";
                      $pass="";
                      $db="ft_db";

                      $conn=new mysqli($servername,$username,$pass,$db);

                      if($conn->connect_error)
                      {
                        die("Connection failed: ".$conn->connect_error);
                      }

                      $sql="SELECT * FROM tbl_product_type";

                      $result=$conn->query($sql);

                      if($result->num_rows > 0)
                      {
                        while($row=$result->fetch_assoc())
                        {
                          echo $row["ptid"]."-".$row["ptype"]."<br/>";
                          echo '<option value="'.$row["ptid"].'">'.$row["ptype"].'</option>';

                        }
                      }


                      ?>
                
                    </select>

                  </div>
               </div>

               <div class="row">
                 <div class="input-field col s6 offset-s3">

                   <button class="btn waves-effect waves-light" type="submit" name="btn_product">Submit

                    </button>

                    <button class="btn waves-effect waves-light" type="reset" name="btn_reset">Reset

                     </button>


                 </div>
               </div>

             </form>
           </center>
           </div>

        </div>

        <div id="test2" class="col s12">





        </div>
        <div id="test3" class="col s12">Test 3</div>
        <div id="test4" class="col s12">Test 4</div>
      </div>


    </div>


    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
  </body>
</html>
