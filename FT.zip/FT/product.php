<?php include('header.php'); ?>


<div id="index-banner" class="parallax-container" style = "min-height:50%;">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
      <h1 class="header center white-text text-lighten-2 head-ft">Future Tech</h1>
      <p class="contact-ft">Your One Stop Service Provider</p>
      <!-- <center><a href = "contact.php"><button class = "btn btn-large blue lighten-1">Contact</button></a></center>  -->
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/contact-fixed.jpg" alt="Unsplashed background img 2"></div>
</div>

<!-- Product Info Section --> 
<br/>
<div class="container">

    <div class="section">
       <div class="row valign-wrapper">
          <div class="col s12 m3 l3 valign"><img class="responsive-img" src="ari.jpg" /></div>
          <div class="col s12 m9 l9"><p align="justify">Nunc pretium diam at sapien gravida ullamcorper. Praesent eu nulla ac mi ornare porta. Duis eget molestie nunc, sed rutrum sapien. Etiam laoreet hendrerit tellus id dignissim. Nunc scelerisque diam massa, id aliquet quam rutrum quis. Curabitur at molestie ex, vitae pulvinar odio. Sed sed mauris ac leo iaculis pellentesque. Integer gravida sem et ante vulputate, ac consequat tellus dictum. Ut aliquet erat sit amet erat viverra molestie. Sed pharetra, tortor at cursus sodales, felis quam tincidunt nunc, ac cursus est neque vitae velit. Pellentesque eget dignissim sapien, eu posuere sem. Suspendisse condimentum elit at imperdiet fermentum. Sed ut pulvinar massa, quis pulvinar ipsum. Fusce porta non eros vitae commodo. Nullam sed nisi nunc.</p></div>
       </div>
    </div>

<div class="section">
       <div class="row valign-wrapper">
          
          <div class="col s12 m9 l9 valign"><p align="justify">Nunc pretium diam at sapien gravida ullamcorper. Praesent eu nulla ac mi ornare porta. Duis eget molestie nunc, sed rutrum sapien. Etiam laoreet hendrerit tellus id dignissim. Nunc scelerisque diam massa, id aliquet quam rutrum quis. Curabitur at molestie ex, vitae pulvinar odio. Sed sed mauris ac leo iaculis pellentesque. Integer gravida sem et ante vulputate, ac consequat tellus dictum. Ut aliquet erat sit amet erat viverra molestie. Sed pharetra, tortor at cursus sodales, felis quam tincidunt nunc, ac cursus est neque vitae velit. Pellentesque eget dignissim sapien, eu posuere sem. Suspendisse condimentum elit at imperdiet fermentum. Sed ut pulvinar massa, quis pulvinar ipsum. Fusce porta non eros vitae commodo. Nullam sed nisi nunc.</p></div>
          <div class="col s12 m3 l3"><img class="responsive-img" src="ari.jpg" /></div>
       </div>
    </div>

    
</div>

<!-- End Product Info Section -->

    <!--  Scripts-->
<?php include('footer.php'); ?>	