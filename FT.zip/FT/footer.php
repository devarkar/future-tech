  <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">Contact Information</h5>
          <p class="grey-text text-lighten-4">No.16 (A-3), Shan Kone St, <br/> Myaynigone (N), Sanchaung Tsp, <br/> Yangon, Myanmar.</p>


        </div>
        <div class="col l3 s12">
          <ul>
            <p>
            <li><a class="white-text" href="tel:+95516687">+95 516 687</a></li>
            <li><a class="white-text" href="tel:+95973080256">+95 9 730 802 56</a></li>
            <li><a class="white-text" href="tel:+9595166400">+95 9 5166400</a></li>
            <li><a class="white-text" href="mailto:yehtut@futuretech.com.mm">yehtut@futuretech.com.mm</a></li>
          </p>
          </ul>
        </div>
        <!-- <div class="col l3 s12">
          <h5 class="white-text">Connect</h5>
          <ul>
            <li><a class="white-text" href="#!">Link 1</a></li>
            <li><a class="white-text" href="#!">Link 2</a></li>
            <li><a class="white-text" href="#!">Link 3</a></li>
            <li><a class="white-text" href="#!">Link 4</a></li>
          </ul>
        </div> -->
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Power by <a class="brown-text text-lighten-3" href="#">Kinetiz Development Team</a>
      </div>
    </div>
  </footer>


  <!--  Scripts-->
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>

  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
      <script>
      $(document).ready(function(){
        $('.slider').slider({full_width: true});
      });
      </script>

  </body>
</html>
		