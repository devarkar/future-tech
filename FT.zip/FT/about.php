<?php include('header.php'); ?>

<section class = "about-us">
  <div class = "container">
  <h1 class = "about-us-heading">About Future Tech</h1>

  <div class = "whoweare">
    <h3 class = "whoweare-heading">Who we are</h3>
    <p class = "flow-text">
      Aliquam finibus placerat turpis in rutrum. Maecenas condimentum sed orci vitae malesuada. Ut accumsan eget diam et dictum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis diam diam. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed lacinia neque a nunc auctor bibendum. Integer consectetur sem in nunc iaculis, sed placerat velit facilisis.
    </p>
  </div>

  <div class = "howwework">
    <h3 class = "howwework-heading">How we work</h3>
    <p class = "howwework-content">
      Aliquam finibus placerat turpis in rutrum. Maecenas condimentum sed orci vitae malesuada. Ut accumsan eget diam et dictum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis diam diam. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed lacinia neque a nunc auctor bibendum. Integer consectetur sem in nunc iaculis, sed placerat velit facilisis.
    </p>
  </div>

  <div class = "spacer"></div>
  <div class = "clients">
  <h1>Our Clients</h1>
  <p>Morbi gravida, nulla ut bibendum bibendum, arcu ipsum feugiat nisi, eu convallis nulla turpis a neque. Sed sodales arcu mauris, a semper orci ultricies in. Pellentesque vitae libero vel felis varius viverra in et mi. Quisque tempus nisi ut tortor vulputate pellentesque. Nunc consectetur scelerisque turpis et commodo. Pellentesque commodo iaculis eros, eu congue metus pretium consectetur. Aliquam in tortor vel nisl consequat semper id et dui. Integer eleifend leo id lacus aliquet pulvinar.</p>
  </div>

  <div class = "row">
        <div class="col s12 m4">

          <!-- Card -->
          <div class="card">
              <div class="card-image waves-effect waves-block waves-light">
                <img class="activator" src="ari.jpg">
              </div>
              <div class="card-content">
                <span class="card-title activator grey-text text-darken-4">Ariana Grande <i class="mdi-navigation-more-vert right"></i></span>
                <p><a href="#">View Details</a></p>
              </div>
              <div class="card-reveal">
                <span class="card-title grey-text text-darken-4">Card Title <i class="mdi-navigation-close right"></i></span>
                <p class = "flow-text">Sed ullamcorper enim rhoncus feugiat vestibulum. Pellentesque eget ex quis sapien facilisis gravida sit amet vitae sapien. Vivamus mauris mi, imperdiet ut placerat quis, accumsan ut ante. Integer suscipit ipsum ut sagittis suscipit. In eu aliquam nisl, a rhoncus metus. Nunc blandit porttitor condimentum. Nullam nec venenatis nunc. Vivamus iaculis eget nunc at blandit. Duis non malesuada diam. Ut et arcu eu eros faucibus interdum. Vestibulum nec sodales libero, a lobortis tellus. Nulla et massa velit. Vivamus gravida blandit est, sed imperdiet diam tempor et. Pellentesque rutrum venenatis dignissim. Sed faucibus porttitor facilisis.</p>
              </div>
            </div>

        </div>
        <div class="col s12 m4">

          <!-- Card -->
          <div class="card">
              <div class="card-image waves-effect waves-block waves-light">
                <img class="activator" src="ari.jpg">
              </div>
              <div class="card-content">
                <span class="card-title activator grey-text text-darken-4">Ariana Grande <i class="mdi-navigation-more-vert right"></i></span>
                <p><a href="#">View Details</a></p>
              </div>
              <div class="card-reveal">
                <span class="card-title grey-text text-darken-4">Card Title <i class="mdi-navigation-close right"></i></span>
                <p>Here is some more information about this product that is only revealed once clicked on.</p>
              </div>
            </div>

        </div>

        <div class="col s12 m4">

          <!-- Card -->
          <div class="card">
              <div class="card-image waves-effect waves-block waves-light">
                <img class="activator" src="ari.jpg">
              </div>
              <div class="card-content">
                <span class="card-title activator grey-text text-darken-4">Ariana Grande <i class="mdi-navigation-more-vert right"></i></span>
                <p><a href="#">View Details</a></p>
              </div>
              <div class="card-reveal">
                <span class="card-title grey-text text-darken-4">Card Title <i class="mdi-navigation-close right"></i></span>
                <p>Here is some more information about this product that is only revealed once clicked on.</p>
              </div>
            </div>

        </div>
        </div>
  <div class = "spacer"></div>
</section>

<?php include('footer.php'); ?>
