<?php

$servername="localhost";
$username="root";
$pass="";
$db="ft_db";

$conn=new mysqli($servername,$username,$pass,$db);

if($conn->connect_error)
{
  die("Connection failed: ".$conn->connect_error);
}

$rel=$_GET["rel"];

$sql="SELECT * FROM tbl_product WHERE pid=$rel";

$result=$conn->query($sql);

if($result->num_rows > 0)
{
  while($row=$result->fetch_assoc())
  {
    $pname=$row["pname"];
    $price=$row["price"];
    $description=$row["description"];
    $img=$row["img"];
    $ptype=$row["ptid"];

  }
}


?>


<?php include('header.php'); ?>
<div class = "container">

  <div class="row">

  <h3 class = "product-model-heading">Model - <?php echo $pname ?></h3>
  <div class = "divider"></div>
<!-- Product Photo -->
<div class= "col s12 m12 l6">
<img class="responsive-img" src = "<?php echo "../".$img; ?>">
</div>
<!-- Product Description -->
<div class = "col s12 m12 l6">
<div class = "product-model-description">
<b>Product Specification</b>
<ul>
  <li>Product Name - <?php echo $pname; ?></li>
  <li>Price - <?php echo $price; ?></li>
  <li>description - <?php echo $description; ?></li>
</ul>
</div>
</div>

</div>

</div>
<?php include('footer.php'); ?>
