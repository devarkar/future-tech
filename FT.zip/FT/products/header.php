<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Futuretech - One Stop Solution Provider</title>

  <!-- CSS  -->
  <link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>

  <!-- Dropdown Structure -->
  <ul id="dropdown1" class="dropdown-content">
    <li><a href="#!">ZyXEL</a></li>
    <li><a href="#!">Link</a></li>
    <li class="divider"></li>
    <li><a href="#!">Panasonic</a></li>
  </ul>

  <ul id="dropdown2" class="dropdown-content">
    <li><a href="#!">Mobile</a></li>
    <li><a href="#!">Network</a></li>
    <li class="divider"></li>
    <li><a href="#!">LSP</a></li>
  </ul>

  <ul id="dropdown3" class="dropdown-content">
    <li><a href="#!">ZyXEL</a></li>
    <li><a href="#!">Link</a></li>
    <li class="divider"></li>
    <li><a href="#!">Panasonic</a></li>
  </ul>

  <ul id="dropdown4" class="dropdown-content">
    <li><a href="#!">Mobile</a></li>
    <li><a href="#!">Network</a></li>
    <li class="divider"></li>
    <li><a href="#!">LSP</a></li>
  </ul>

  <nav class="light-blue" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo">Future Tech</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Product<i class="mdi-navigation-arrow-drop-down right"></i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Service<i class="mdi-navigation-arrow-drop-down right"></i></a></li>
        <li><a href="contact.php">Contact</a></li>

      </ul>



      <ul id="nav-mobile" class="side-nav">

        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">Product<i class="mdi-navigation-arrow-drop-down right"></i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">Service<i class="mdi-navigation-arrow-drop-down right"></i></a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="mdi-navigation-menu"></i></a>
    </div>
  </nav>
