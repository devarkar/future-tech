<?php include('header.php'); ?>

<!-- Service img slider -->

<div class="slider">
    <ul class="slides">
      <li>
        <img src="img/network2.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3>This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="img/network-fixed.jpg"> <!-- random image -->
        <div class="caption left-align">
          <h3>Left Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="ari.jpg"> <!-- random image -->
        <div class="caption right-align">
          <h3>Right Aligned Caption</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
      <li>
        <img src="ari.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3>This is our big Tagline!</h3>
          <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
        </div>
      </li>
    </ul>
  </div>

      <script>
      $(document).ready(function(){
        $('.slider').slider({full_width: true});
      });
      </script>
<!-- End of Slider -->


<!-- Card Section -->
<div class="container">
       <div class="row">
        <div class="col s12 m12 l12">
          <div class="card blue-grey darken-1">
            <div class="card-content white-text">
              <span class="card-title">Card Title</span>
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
            <div class="card-action">
              <a href="#">This is a link</a>
              <a href="#">This is a link</a>
            </div>
          </div>
        </div>
      </div>

       <div class="row">
        <div class="col s12 m12 l12">
          <div class="card blue-grey darken-1">
            <div class="card-content white-text">
              <span class="card-title">Card Title</span>
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
            <div class="card-action">
              <a href="#">This is a link</a>
              <a href="#">This is a link</a>
            </div>
          </div>
        </div>
      </div>
</div> <!-- container end -->
<!-- End of Card Section -->




<!-- Tab Section -->

<div class="container">
<div class="row">
    <div class="col s12">
      <ul class="tabs">
        <li class="tab col s3"><a href="#test1">GSM Service</a></li>
        <li class="tab col s3"><a class="active" href="#test2">Corporate Network Service</a></li>
        <li class="tab col s3 disabled"><a href="#test3">PABX Service</a></li>
        <li class="tab col s3"><a href="#test4">IP Telephony</a></li>
      </ul>
    </div>
    <div id="test1" class="col s12">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Ut ullamcorper eget justo vel scelerisque. Cras elit sem, 
        hendrerit non cursus cursus, sodales quis ex. Nunc lacinia 
        nunc consequat viverra auctor. Aliquam neque libero, 
        sollicitudin a vestibulum quis, dictum ornare nibh. Ut facilisis 
        pretium egestas. Duis vulputate elementum ligula. Aliquam erat 
        volutpat. Aenean eu felis in metus cursus euismod vitae et dolor. 
        Fusce maximus, sapien ac imperdiet maximus, elit mi commodo turpis, 
        quis lacinia neque augue eget velit. Maecenas eu elementum est. 
        Curabitur ut posuere justo, non imperdiet augue.
    </div>
    
    <div id="test2" class="col s12">
        Nullam convallis facilisis magna auctor porta. 
        Aliquam erat volutpat. Proin quis efficitur magna. 
        Cras posuere iaculis ipsum, eu sodales lacus sollicitudin a. 
        Fusce augue augue, consequat in finibus quis, auctor a tortor. 
        Integer quis sapien convallis, lacinia dui ut, faucibus mauris. 
        Aenean in auctor tortor.
    </div>

    <div id="test3" class="col s12">
        Nunc pretium diam at sapien gravida ullamcorper. 
        Praesent eu nulla ac mi ornare porta. Duis eget 
        molestie nunc, sed rutrum sapien. Etiam laoreet 
        hendrerit tellus id dignissim. Nunc scelerisque 
        diam massa, id aliquet quam rutrum quis. Curabitur at molestie 
        ex, vitae pulvinar odio. Sed sed mauris ac leo iaculis pellentesque. 
        Integer gravida sem et ante vulputate, ac consequat tellus dictum. 
        Ut aliquet erat sit amet erat viverra molestie. Sed pharetra, 
        tortor at cursus sodales, felis quam tincidunt nunc, ac cursus 
        est neque vitae velit. Pellentesque eget dignissim sapien, eu posuere 
        sem. Suspendisse condimentum elit at imperdiet fermentum. Sed ut pulvinar 
        massa, quis pulvinar ipsum. Fusce porta non eros vitae commodo. Nullam sed nisi nunc.
    </div>
    <div id="test4" class="col s12">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Ut ullamcorper eget justo vel scelerisque. Cras elit sem, 
        hendrerit non cursus cursus, sodales quis ex. Nunc lacinia 
        nunc consequat viverra auctor. Aliquam neque libero, 
        sollicitudin a vestibulum quis, dictum ornare nibh. Ut facilisis 
        pretium egestas. Duis vulputate elementum ligula. Aliquam erat 
        volutpat. Aenean eu felis in metus cursus euismod vitae et dolor. 
        Fusce maximus, sapien ac imperdiet maximus, elit mi commodo turpis, 
        quis lacinia neque augue eget velit. Maecenas eu elementum est. 
        Curabitur ut posuere justo, non imperdiet augue.
    </div>
  </div>
</div>
<br/> <br/> <br/>
<!-- End of Tab Section -->



<?php include('footer.php'); ?>	