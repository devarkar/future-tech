<?php include('header.php'); ?>


<div id="index-banner" class="parallax-container">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
        <img src = "img/ft.PNG" class = "logo-image" align = "middle" alt = "Future Tech">
      <h1 class="header center white-text text-lighten-2 head-ft">FUTURE TECH</h1>
      <h3 class="header center white-text text-lighten-2">Your One Stop Service Provider</h3>
      <div class = "spacer"></div>
        <img src = "img/scroll.png" class = "scroll-img" alt = "Please scroll down">
                <p class = "scroll-text">Scroll Down</p>
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/network-fixed.jpg" alt="Unsplashed background img 2"></div>
</div>

<!-- Background History Section -->
<div id="index-banner" class="parallax-container">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
        <div class = "spacer"></div>
      <h1 class="header center white-text text-lighten-2 head-ft">COMPANY BACKGROUND HISTORY</h1>
      <br><br>
      <p class="about-ft">Nam ac dolor vestibulum, pellentesque nisl sed, pharetra quam. Sed eu enim sit amet elit finibus porttitor vitae ut elit. Morbi ut quam magna. Quisque dapibus nisl vel tellus pellentesque iaculis. Aliquam sagittis luctus scelerisque. Quisque vestibulum purus eu enim mollis interdum. Sed dui velit, tempor sit amet eros quis, facilisis tristique magna.</p>
      <div class = "spacer"></div>
      <center><a href = "about.php"><button class = "btn btn-large blue lighten-1">More</button></a></center>
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/network2.jpg" alt="Unsplashed background img 2"></div>
</div>

<!-- Services and Products Section -->
<div id="index-banner" class="parallax-container">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
        <div class = "spacer"></div>
      <h1 class="header center white-text text-lighten-2 head-ft">Services & Products</h1>
      <br><br>
      <p class="about-ft">Nam ac dolor vestibulum, pellentesque nisl sed, pharetra quam. Sed eu enim sit amet elit finibus porttitor vitae ut elit. Morbi ut quam magna. Quisque dapibus nisl vel tellus pellentesque iaculis. Aliquam sagittis luctus scelerisque. Quisque vestibulum purus eu enim mollis interdum. Sed dui velit, tempor sit amet eros quis, facilisis tristique magna.</p>
      <div class = "spacer"></div>
      <center><a href = "about.php"><button class = "btn btn-large blue lighten-1">More</button></a></center>
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/network2.jpg" alt="Unsplashed background img 2"></div>
</div>

<!-- Our Clients -->
<div id="index-banner" class="parallax-container">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
        <div class = "spacer"></div>
      <h1 class="header center white-text text-lighten-2 head-ft">Our Clients</h1>
      <br><br>
      <!--<p class="about-ft">Place for client logo!</p>-->

<!-- Client Logo Places -->
<div class='row'>
    <div class='col s12 m6 l3'><img class="responsive-img" src="ari.jpg"></div>
    <div class='col s12 m6 l3'><img class="responsive-img" src="ari.jpg"></div>
    <div class='col s12 m6 l3'><img class="responsive-img" src="ari.jpg"></div>
    <div class='col s12 m6 l3'><img class="responsive-img" src="ari.jpg"></div>

</div>
<!-- Client Logo End -->


      <div class = "spacer"></div>
      <center><a href = "about.php"><button class = "btn btn-large blue lighten-1">More</button></a></center>
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/network2.jpg" alt="Unsplashed background img 2"></div>
</div>

<div id="index-banner" class="parallax-container" style = "min-height:70%;">
  <div class="section">
    <div class="container">
      <div class = "row text-block">
      <h1 class="header center white-text text-lighten-2 head-ft">CONTACT US</h1>
      <p class="contact-ft">Do you want to work with us?</p>
      <center><a href = "contact.php"><button class = "btn btn-large blue lighten-1">Contact</button></a></center>
      <br><br>
    </div>
    </div>
  </div>
  <div class="parallax"><img src="img/contact-fixed.jpg" alt="Unsplashed background img 2"></div>
</div>

    <!--  Scripts-->
<?php include('footer.php'); ?>
